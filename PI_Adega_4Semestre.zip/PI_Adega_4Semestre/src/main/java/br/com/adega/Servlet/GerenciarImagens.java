package br.com.adega.Servlet;

import br.com.adega.DAO.ProdutoDAO;
import br.com.adega.Model.Imagem;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet("/gerenciarImagem")
public class GerenciarImagens extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int codProduto = Integer.parseInt(request.getParameter("codProduto"));
        List<Imagem> imagensProduto = ProdutoDAO.obterImagensPorProdutoId(codProduto); // Implemente essa lógica conforme necessário

        if (!imagensProduto.isEmpty()) {
            request.setAttribute("imagensProduto", imagensProduto);
        }
        request.setAttribute("codProduto", codProduto);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/GerenciarImagem.jsp");
        dispatcher.forward(request, response);
    }


    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    int codProduto = Integer.parseInt(request.getParameter("codProduto"));

        List<Part> fileParts = request.getParts().stream()
                .filter(part -> "selImagem".equals(part.getName()))
                .collect(Collectors.toList());

        String diretorio = "imagens";
        String diretorioAbsoluto = getServletContext().getRealPath("/" + diretorio);
        File diretorioImagens = new File(diretorioAbsoluto);
        if (!diretorioImagens.exists()) {
            diretorioImagens.mkdirs();
        }

        List<Imagem> nomesImagensExistentes = ProdutoDAO.obterImagensPorProdutoId(codProduto);
        boolean imagemAdicionada = false;

        for (Part filePart : fileParts) {
            String fileName = extractFileName(filePart);
            if (!fileName.isEmpty()) {
                String novoNome = "imagem_" + System.currentTimeMillis() + "_" + fileName;
                String filePath = diretorioAbsoluto + File.separator + novoNome;
                filePart.write(filePath);

                // Salvar informações da imagem no banco de dados
                Imagem imagem = new Imagem();
                imagem.setProdutoId(codProduto);
                imagem.setDiretorio(diretorio);
                imagem.setNome(novoNome);
                imagem.setExtensao(fileName.substring(fileName.lastIndexOf(".") + 1));

                // Verificar e atualizar qualificação das imagens
                boolean imagemJaExiste = false;
                for (Imagem img : nomesImagensExistentes) {
                    if (img.getNome().equals(novoNome)) {
                        imagemJaExiste = true;
                        imagem.setQualificacao(img.isQualificacao()); // Manter a qualificação da imagem existente
                        break;
                    }
                }
                if (!imagemJaExiste) {
                    imagem.setQualificacao(false); // Definir como false por padrão
                }

                //    ProdutoDAO.adicionarOuAtualizarImagem(imagem);

                imagemAdicionada = true;
            }
        }


    }

    private String extractFileName(Part part) {
        String contentDisp = part.getHeader("content-disposition");
        String[] tokens = contentDisp.split(";");
        for (String token : tokens) {
            if (token.trim().startsWith("filename")) {
                return token.substring(token.indexOf("=") + 2, token.length() - 1);
            }
        }
        return "";
    }
}